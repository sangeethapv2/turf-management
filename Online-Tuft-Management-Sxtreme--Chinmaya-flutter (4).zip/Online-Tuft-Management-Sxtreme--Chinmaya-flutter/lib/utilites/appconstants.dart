import 'dart:ui';

class AppConstants{


  static Color  primarycolors = Color.fromRGBO(64,183,99,1);
  static Color  boldText = Color.fromRGBO(16,116,46,1);


}